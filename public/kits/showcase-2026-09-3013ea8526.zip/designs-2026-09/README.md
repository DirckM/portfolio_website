# Four app screens, rebuilt in HTML and animated

The code for the screens in "Made this month", issue 001 (September) of Dirck Mulder's newsletter. dirckmulder.com/newsletter

Each folder is one screen: plain HTML, CSS and a little JavaScript, no build step. Open its index.html in a browser. Free to learn from and reuse in your own work.

## Credit

All four are rebuilt from screens I saved on Pinterest. I could not trace who designed them, and the disc carousel is the only one with a pin (pinterest.com/pin/744360644694129716). If one of them is yours, tell me and I will put your name here.

## mood-check-in/

A mood check-in with a jelly mascot that changes colour and face for every mood.

Open `mood-check-in/index.html` in a browser.

## job-swipe-welcome/

A job app welcome where the card deck scores and swipes itself.

Open `job-swipe-welcome/index.html` in a browser.

## disc-carousel/

A carousel of stacked discs that squash, scale and blur as they pass the middle.

Open `disc-carousel/index.html` in a browser.
Stickers: Microsoft Fluent Emoji 3D, MIT licence (assets/emoji3d/LICENSE.txt).

## collections-empty-state/

An empty state with a fan of tilted photos and a detached add button.

Open `collections-empty-state/index.html` in a browser.
Avatar: DiceBear "Personas" by Draftbit, CC BY 4.0.
Photos: night-lights.jpg (CC0, StockSnap), jp-neon.jpg (CC0, StockSnap), jp-torii.jpg (CC0, StockSnap).

## Fonts

No font files are included. Fraunces, Hanken Grotesk, Geist Mono, Newsreader and Plus Jakarta Sans load from Google Fonts, General Sans and Cabinet Grotesk from Fontshare (fontshare.com). You need to be online for them.
