/* Bare mode for gallery previews.
   index.html embeds each screen as `screens/NN-name.html#bare` inside a 430x878
   iframe cropped to the phone. Without this the iframe renders the whole essay
   page — kicker, h1, lede, "Why it fits" — and the crop lands on text instead of
   the device. When the hash is #bare we strip the prose chrome and leave the
   device alone, centred at the top of the frame. */
(function () {
  if (window.location.hash !== '#bare') return;

  var css = document.createElement('style');
  css.textContent =
    '.stage{padding:22px 0 0!important;min-height:0!important;background:none!important}' +
    '.stage__head,.note,.lbl,.foot,.stage>h1,.stage>.lede{display:none!important}' +
    '.row{margin:0!important;justify-content:center!important}' +
    '.frame-cap{margin:0!important}' +
    'body{background:transparent!important;overflow:hidden!important}';
  document.head.appendChild(css);
  document.documentElement.classList.add('bare');
})();
